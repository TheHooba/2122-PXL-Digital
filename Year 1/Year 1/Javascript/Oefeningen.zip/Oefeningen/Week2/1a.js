const min = (number1, number2) => number1 < number2 ? number1 : number2;

console.log(min(1, 2));