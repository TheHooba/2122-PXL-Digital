class Account{

}
let account = new new Account("BE", "97", "0011223344", 2222);
account.withdraw(22);
account.deposit(1);
account.print();