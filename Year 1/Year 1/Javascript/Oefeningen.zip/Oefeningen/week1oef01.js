let text = "";
let aantal = 7;
for ( let i = 0; i<=aantal; i++)
{
    text += "#";
    console.log(text);
}