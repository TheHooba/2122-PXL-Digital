// Maak een functie minimum die het minimum van 2 number waarden berekent
//en teruggeeft, maak geen gebruik van Math.min

let getal1, getal2;
getal1 = 7000000000000; getal2 = 1;
function min(number1, number2)
{
    if(getal1 > getal2)
    {
        return ("Getal 1 is groter!");
    }
    return ("Getal 2 is groter!!!!!!!!!!!!!!!!!!!!!!!!!!!");
}
console.log(min());

//Pas de functie minimum aan zodanig dat er ook meerdere waarden
//meegegeven kunnen worden bij het aanroepen van de functie, maak geen
//gebruik van Math.min


