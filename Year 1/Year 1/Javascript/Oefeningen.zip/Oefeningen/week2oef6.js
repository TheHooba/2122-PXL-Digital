/* Maak een functie reverseArray. Deze functie neemt een array als argument en geeft de
array in omgekeerde volgorde terug. Het argument blijft ongewijzigd.
let a= [1,2,3];
let b=reverseArray(a);
Maak geen gebruik van de voorgedefinieerde reverse functie. */

function reverseArray(...letters)
{
    let a= [1,2,3];
    let b=reverseArray(a);
}